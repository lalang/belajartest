<?php
return [
    'adminEmail' => 'bptsp@jakarta.go.id',
    'maskMoneyOptions' => [
        'prefix' => '',
        'suffix' => '',
        'affixesStay' => true,
        'thousands' => '.',
        'decimal' => ',',
        'precision' => 2,
        'allowZero' => false,
        'allowNegative' => false,
    ],
    'cekDJP' => 'Tidak'
];
